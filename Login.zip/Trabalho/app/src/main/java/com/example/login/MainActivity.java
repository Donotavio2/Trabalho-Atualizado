package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String nome = getIntent().getStringExtra("nome");
        Log.d("Listar: Nome", nome);
        String email = getIntent().getStringExtra("email");
        Log.d("Listar: email", email);
        String password = getIntent().getStringExtra("password");
        Log.d("Listar: password", password);
        String impostorSelecionado = getIntent().getStringExtra("impostorSelecionado");
        Log.d("Listar: impostor", impostorSelecionado);
        String ZoeiroSelecionado = getIntent().getStringExtra("ZoeiroSelecionado");
        Log.d("Listar: Zoeiro", ZoeiroSelecionado);
        String SobreviventeSelecionado = getIntent().getStringExtra("SobreviventeSelecionado");
        Log.d("Listar: Sobrevivente", SobreviventeSelecionado);
        String NseiPqToAquiSelecionado = getIntent().getStringExtra("NseiPqToAquiSelecionado");
        Log.d("Listar: Nsei", NseiPqToAquiSelecionado);
        String masculinoSelecionado = getIntent().getStringExtra("masculinoSelecionado");
        Log.d("Listar: masculino", masculinoSelecionado);
        String femininoSelecionado = getIntent().getStringExtra("femininoSelecionado");
        Log.d("Listar: feminino", femininoSelecionado);
        String cor = getIntent().getStringExtra("cor");
        Log.d("Listar: cor", cor);


        TextView myTextView;
        myTextView = findViewById(R.id.edit_nome);
        myTextView.setText(nome);
        myTextView = findViewById(R.id.edit_email);
        myTextView.setText(email);
        myTextView = findViewById(R.id.edit_cor);
        myTextView.setText(cor);
        myTextView = findViewById(R.id.edit_sex);

        if(masculinoSelecionado.equals("true")) {
            myTextView.setText("Masculino");
        }else{
            myTextView.setText("Feminino");
        }

        myTextView = findViewById(R.id.edit_extra);

        if(impostorSelecionado.equals("true")) {
            myTextView.setText("impostorSelecionado");
        } else if (ZoeiroSelecionado.equals("true")) {
            myTextView.setText("ZoeiroSelecionado");
        } else if (SobreviventeSelecionado.equals("true")) {
            myTextView.setText("SobreviventeSelecionado");

        }else if (NseiPqToAquiSelecionado.equals("true")) {
            myTextView.setText("NseiPqToAquiSelecionado");
    }




        Button listar;

        listar = (Button) findViewById(R.id.listar);

        listar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Código a ser executado quando o botão é clicado
                Log.d("Meu aplicativo", "O botão foi clicado!");

            }
        });



    }
}