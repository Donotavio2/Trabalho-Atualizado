package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

import java.io.File;

public class FormCadastro extends AppCompatActivity implements AdapterView.OnItemClickListener {

    String nome;
    String email;
    String password;
    boolean impostorSelecionado;
    boolean ZoeiroSelecionado;
    boolean SobreviventeSelecionado;
    boolean NseiPqToAquiSelecionado;
    boolean masculinoSelecionado;
    boolean femininoSelecionado;
    String cor;
    SQLiteDatabase bancoDados;

    String nomeBancoDados = "AmongUs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_cadastro);

        EditText editTextNome = (EditText) findViewById(R.id.edit_nome);
        EditText editTextEmail = (EditText) findViewById(R.id.edit_email);
        EditText editTextSenha = (EditText) findViewById(R.id.edit_senha);
        CheckBox checkboxImpostor = ((CheckBox) findViewById(R.id.checkBox7));
        CheckBox checkboxZueiro = ((CheckBox) findViewById(R.id.checkBox8));
        CheckBox checkboxSobrevivente = (CheckBox) findViewById(R.id.checkBox9);
        CheckBox checkboxNemseiporquetoaqui  = (CheckBox) findViewById(R.id.checkBox10);
        RadioButton radioMasculino = ((RadioButton) findViewById(R.id.radioButton));
        RadioButton radioFeminino = ((RadioButton) findViewById(R.id.radioButton2));

        Button bt_cadastro = (Button) findViewById(R.id.bt_cadastrar);

        Spinner spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        bt_cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { // Essa função é responsável pela ação ao clicar no botão cadastrar. Pq? pq nesse ponto do tempo nós já vamos ter os valores inputados
                nome = editTextNome.getText().toString(); // Essa atribuição é guardar o valor na variavel global. Pq? dessa forma iremos poder utilizar na função do banco
                email = editTextEmail.getText().toString();
                password = editTextSenha.getText().toString();
                impostorSelecionado = (Boolean) checkboxImpostor.isChecked();
                ZoeiroSelecionado = (Boolean) checkboxZueiro.isChecked();
                SobreviventeSelecionado = (Boolean) checkboxSobrevivente.isChecked();
                NseiPqToAquiSelecionado = (Boolean) checkboxNemseiporquetoaqui.isChecked();
                masculinoSelecionado = radioMasculino.isChecked();
                femininoSelecionado = radioFeminino.isChecked();
                cor = spinner.getSelectedItem().toString();

                bt_cadastro.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(FormCadastro.this, MainActivity.class);
                        intent.putExtra("nome", nome);
                        intent.putExtra("email", email);
                        intent.putExtra("password", password);
                        intent.putExtra("impostorSelecionado", ""+impostorSelecionado);
                        intent.putExtra("ZoeiroSelecionado", ""+ZoeiroSelecionado);
                        intent.putExtra("SobreviventeSelecionado", ""+SobreviventeSelecionado);
                        intent.putExtra("NseiPqToAquiSelecionado", ""+ NseiPqToAquiSelecionado);
                        intent.putExtra("masculinoSelecionado", ""+ masculinoSelecionado);
                        intent.putExtra("femininoSelecionado", ""+ femininoSelecionado);
                        intent.putExtra("cor", cor);




                        startActivity(intent);
                    }
                });

                //cadastrar_Usuario(); // Estamos chamando (invocando) uma função, e passando nada por parametro.
            }
        });
    }

    public void cadastrar_Usuario() {
        Log.d("GLOBAL: Nome", nome);
        Log.d("GLOBAL: Email", email);
        Log.d("GLOBAL: Senha", password);
        Log.d("GLOBAL: Impostor", impostorSelecionado + "");
        Log.d("GLOBAL: Zoeiro", ZoeiroSelecionado + "");
        Log.d("GLOBAL: Sobrevivente", SobreviventeSelecionado + "");
        Log.d("GLOBAL: NseiPqToAqui", NseiPqToAquiSelecionado + "");
        Log.d("GLOBAL: Masculino", masculinoSelecionado + "");
        Log.d("GLOBAL: Feminino", femininoSelecionado + "");
        Log.d("GLOBAL: cor", cor);

        try {
            bancoDados = openOrCreateDatabase(nomeBancoDados, MODE_PRIVATE, null);
            String sql;
            SQLiteStatement stmt;
            if (!exiteBancoDeDadosCriado()) {
                sql = "CREATE TABLE AmongUs (nome varchar(100), email varchar(255), password varchar(10), impostorSelecionado boolean, ZoeiroSelecionado boolean, SobreviventeSelecionado boolean, NseiPqToAquiSelecionado boolean, masculinoSelecionado boolean, femininoSelecionado boolean, cor varchar(50));";
                stmt = bancoDados.compileStatement(sql);
                stmt.executeInsert();
            }

            // INSERIR DADOS
            ContentValues values = new ContentValues();
            values.put("nome", nome);
            values.put("email", email);
            bancoDados.insert(nomeBancoDados, null, values);

            // LER DADOS
            Cursor c = bancoDados.rawQuery("SELECT * FROM AmongUs", null);
            if (c.moveToFirst()){
                do {
                    // Passing values
                    String column1 = c.getString(0);
                } while(c.moveToNext());
            }
            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean exiteBancoDeDadosCriado() {
        File dbFile = this.getDatabasePath(nomeBancoDados);
        return dbFile.exists();
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        //String text = parent.getItemAtPosition(position).toString();

    }
    //@Override
    //public void onNothingSelected(AdapterView<?> parent){

    }

